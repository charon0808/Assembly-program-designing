void proc(struct ele *up){
    up-> y[2]= *(up-> e1.p)+up-> y[2];
}

